# Vibez — Hi-Res Local Music Player

مشغّل ملفات خاص (Private) بواجهة Liquid Glass مستوحاة من Qobuz — جميع المراحل مكتملة.

## الواجهات (مطابقة للصور)
- Discover · Library (قائمة/شبكة + فلاتر + Recently added) · Search · Player · Quality Settings
- Mini player سفلي دائم · شريط تنقل سفلي 4 تبويبات · شارة Hi-Res الذهبية
- Liquid Glass (widgets/glass.dart) · خط Fraktur لشعار Vibez · خلفية ديناميكية من ألوان الغلاف

## المحرك (كل المراحل)
| الميزة | الحالة | الملف |
|---|---|---|
| كشف الدقة الحقيقية (WAV/FLAC headers، بدون إنترنت) | ✅ | services/audio_probe.dart |
| سلة الجودات 24/192 · 24/96 · CD · MP3 مع منع الاختيار الأعلى من المصدر | ✅ | models/quality.dart |
| تحويل فعلي بـ FFmpeg إلى ملف مؤقت (wav s32 / mp3 lame 320k) | ✅ | services/quality_converter.dart |
| Gapless طابور كامل (ConcatenatingAudioSource) | ✅ | services/player_service.dart |
| Crossfade (لاعبان متزامنان) | ✅ | services/player_service.dart |
| أغلفة من وسوم الملفات + ألوان ديناميكية (palette) | ✅ | services/library_service.dart |
| تشغيل خلفي + إشعار + شاشة القفل + أزرار السماعة (MediaSession) | ✅ | just_audio_background |
| إعدادات Default audio quality بنفس تصميم الصورة المرجعية | ✅ | screens/quality_settings_screen.dart |

## التشغيل
```bash
flutter create . --org com.vibez     # يولّد مجلد android/ios (الملفات المحلية محفوظة)
flutter pub get
flutter run                          # على جهاز حقيقي لمنح أذونات التخزين
```

## الرفع على GitHub (خاص)
```bash
git init && git add -A && git commit -m "vibez: full player"
gh repo create vibez --private --source=. --push
```

## أفكار مستقبلية (اختيارية)
- [ ] Android Auto شاشة كاملة (تتطلب MediaBrowserService مخصص بدل just_audio_background)
- [ ] Waveform seekbar حقيقي (حساب مُخزن لكل ملف)
- [ ] ReplayGain من وسوم الملفات
- [ ] SMB/WebDAV استيراد من NAS
