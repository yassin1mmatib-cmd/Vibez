import 'package:flutter/material.dart';

enum Quality { hires192, hires96, cd, mp3 }

extension QualityX on Quality {
  String get label => switch (this) {
        Quality.hires192 => 'Hi-Res 24/192',
        Quality.hires96 => 'Hi-Res 24/96',
        Quality.cd => 'CD 16/44.1',
        Quality.mp3 => 'MP3 320 kbps',
      };

  // rank: lower number = higher quality
  int get rank => switch (this) {
        Quality.hires192 => 1,
        Quality.hires96 => 2,
        Quality.cd => 3,
        Quality.mp3 => 4,
      };

  double get bitrateMbps => switch (this) {
        Quality.hires192 => 9.216,
        Quality.hires96 => 4.608,
        Quality.cd => 1.4112,
        Quality.mp3 => 0.32,
      };

  /// Gold badge used on the quality settings screen (matches screenshots).
  Widget badge({double size = 40}) {
    switch (this) {
      case Quality.hires192:
      case Quality.hires96:
        return ClipRRect(
          borderRadius: BorderRadius.circular(size / 2),
          child: Image.asset('assets/badges/hires_badge.png',
              width: size, height: size, fit: BoxFit.cover),
        );
      case Quality.cd:
        return _roundIcon(Icons.album, size);
      case Quality.mp3:
        return _roundIcon(Icons.music_note, size, label: 'MP3');
    }
  }

  Widget _roundIcon(IconData icon, double size, {String? label}) {
    return Container(
      width: size, height: size,
      decoration: const BoxDecoration(
        color: Color(0xFF2A2A31), shape: BoxShape.circle,
      ),
      child: Center(
        child: label == null
            ? Icon(icon, color: Colors.white70, size: size * 0.5)
            : Text(label,
                style: TextStyle(
                    color: AppGold.x, fontWeight: FontWeight.w700,
                    fontSize: size * 0.28)),
      ),
    );
  }
}

class AppGold {
  static const Color x = Color(0xFFE8B44A);
}

/// Whether [out] can be produced from a [source] file.
bool canConvert({required Quality source, required Quality out}) =>
    out.rank >= source.rank;
