import 'quality.dart';

class Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String? artPath;      // embedded/local cover art
  final String filePath;
  final Duration duration;
  final Quality sourceQuality;
  final String format;        // FLAC, WAV, MP3...

  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.filePath,
    required this.duration,
    required this.sourceQuality,
    this.artPath,
    this.format = 'FLAC',
  });

  bool get isHiRes => sourceQuality.rank <= Quality.hires96.rank;
}
