import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Qobuz-like dark palette
  static const Color bg = Color(0xFF0B0B0E);
  static const Color surface = Color(0xFF16161B);
  static const Color card = Color(0xFF1E1E24);
  static const Color gold = Color(0xFFE8B44A);
  static const Color textMain = Color(0xFFF2F2F5);
  static const Color textDim = Color(0xFF9A9AA3);

  static TextStyle fraktur(double size, {Color color = textMain}) {
    // Gothic display font for the "Vibez" wordmark (Latin only).
    return GoogleFonts.unifrakturMaguntia(fontSize: size, color: color);
  }

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: base.colorScheme.copyWith(
        primary: gold, surface: surface, onSurface: textMain,
      ),
      textTheme: base.textTheme.apply(
        bodyColor: textMain, displayColor: textMain,
      ),
      dividerColor: Colors.white12,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent, elevation: 0, centerTitle: false,
      ),
    );
  }
}
