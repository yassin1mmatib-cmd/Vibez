import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:audiotags/audiotags.dart' as tags;
import '../models/quality.dart';
import '../models/track.dart';
import 'audio_probe.dart';

/// Scans device storage, reads REAL quality from file headers (AudioProbe),
/// extracts embedded artwork to temp files, and builds the library index.
class LibraryService extends ChangeNotifier {
  final List<Track> tracks = [];
  bool scanning = false;
  Directory? _artDir;

  static const _exts = {'.flac', '.wav', '.mp3', '.m4a', '.aac',
                       '.ogg', '.opus', '.dsf', '.ape'};

  Future<void> scan() async {
    scanning = true;
    notifyListeners();
    await Permission.storage.request();
    if (Platform.isAndroid) await Permission.manageExternalStorage.request();

    tracks.clear();
    final roots = [Directory('/storage/emulated/0/Music'),
                   Directory('/storage/emulated/0/Download')];
    for (final r in roots) {
      if (await r.exists()) await _walk(r);
    }
    scanning = false;
    notifyListeners();
  }

  Future<void> _walk(Directory dir) async {
    try {
      await for (final e in dir.list(recursive: true, followLinks: false)) {
        if (e is! File) continue;
        final ext = e.path.substring(e.path.lastIndexOf('.')).toLowerCase();
        if (!_exts.contains(ext)) continue;
        final t = await _read(e);
        if (t != null) tracks.add(t);
      }
    } catch (_) {/* skip restricted dirs */}
    notifyListeners();
  }

  Future<Track?> _read(File f) async {
    try {
      final tag = await tags.AudioTags.read(f.path);
      final (sr, bits, format) = await AudioProbe.probe(f.path);
      final q = AudioProbe.detectQuality(sr, bits, format);
      final art = await _extractArt(f.path, tag);
      return Track(
        id: f.path,
        title: tag?.title ?? f.uri.pathSegments.last,
        artist: (tag?.artists ?? ['Unknown']).join(', '),
        album: tag?.album ?? 'Unknown Album',
        filePath: f.path,
        duration: Duration(seconds: tag?.duration?.inSeconds ?? 0),
        sourceQuality: q,
        format: format,
        artPath: art,
      );
    } catch (_) {
      return null;
    }
  }

  Future<String?> _extractArt(String path, tags.Tag? tag) async {
    if (tag == null || tag.pictures.isEmpty) return null;
    try {
      _artDir ??= Directory('${(await getTemporaryDirectory()).path}/vibez_art')
        ..createSync(recursive: true);
      final out = File('${_artDir!.path}/${path.hashCode}.jpg');
      if (!await out.exists()) await out.writeAsBytes(tag.pictures.first.bytes);
      return out.path;
    } catch (_) {
      return null;
    }
  }
}
