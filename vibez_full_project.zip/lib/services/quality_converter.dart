import 'dart:io';
import 'package:ffmpeg_kit_flutter_audio/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_audio/return_code.dart';
import 'package:path_provider/path_provider.dart';
import '../models/quality.dart';
import '../models/track.dart';

/// Real quality conversion: transcodes the source file into a temp
/// cache file at the requested quality, then hands it to the player.
/// Cache is cleared on app start; files are reused within the session.
class QualityConverter {
  Directory? _cache;

  Future<Directory> _dir() async {
    _cache ??= Directory('${(await getTemporaryDirectory()).path}/vibez_conv');
    if (await _cache!.exists()) await _cache!.delete(recursive: true);
    await _cache!.create(recursive: true);
    return _cache!;
  }

  static int _rate(Quality q) => switch (q) {
        Quality.hires192 => 192000,
        Quality.hires96 => 96000,
        Quality.cd => 44100,
        Quality.mp3 => 44100,
      };

  Future<File> convert(Track t, Quality q) async {
    final dir = await _dir();
    final out = File('${dir.path}/${t.id.hashCode}_${q.name}'
        '${q == Quality.mp3 ? '.mp3' : '.wav'}');
    if (await out.exists()) return out;

    final args = q == Quality.mp3
        ? '-y -i "${t.filePath}" -vn -codec:a libmp3lame -b:a 320k "${out.path}"'
        : '-y -i "${t.filePath}" -vn -ar ${_rate(q)} -ac 2 -sample_fmt s32 "${out.path}"';

    final session = await FFmpegKit.execute(args);
    if (!ReturnCode.isSuccess(await session.getReturnCode())) {
      throw Exception('FFmpeg failed: ${await session.getOutput()}');
    }
    return out;
  }
}
