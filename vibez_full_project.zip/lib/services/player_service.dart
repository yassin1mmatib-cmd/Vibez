import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../models/quality.dart';
import '../models/track.dart';
import 'quality_converter.dart';

/// Full playback engine:
/// - gapless queue via ConcatenatingAudioSource
/// - real quality conversion via FFmpeg when output < source
/// - optional two-player crossfade
/// - MediaSession/lock-screen metadata for every track
class PlayerService extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  final AudioPlayer _fadePlayer = AudioPlayer(); // crossfade only
  final QualityConverter _converter = QualityConverter();

  final List<Track> queue = [];
  int _fallbackIndex = 0;

  Quality outputQuality = Quality.cd;
  bool gapless = true;
  double crossfadeSeconds = 0; // 0 = disabled

  PlayerService() {
    _player.currentIndexStream.listen(_onIndexChanged);
    _player.positionStream.listen((_) => notifyListeners());
    _player.playingStream.listen((_) => notifyListeners());
    _player.durationStream.listen((_) => notifyListeners());
  }

  int get _idx => _player.currentIndex ?? _fallbackIndex;
  Track? get current => queue.isEmpty ? null : queue[_idx.clamp(0, queue.length - 1)];
  Duration get position => _player.position;
  Duration get duration => _player.duration ?? Duration.zero;
  bool get playing => _player.playing;

  Future<void> setQueue(List<Track> tracks, int index) async {
    queue
      ..clear()
      ..addAll(tracks);
    _fallbackIndex = index;
    notifyListeners();

    if (crossfadeSeconds > 0) {
      await _playSingle(tracks[index]);
      return;
    }
    if (gapless) {
      final sources = <AudioSource>[];
      for (final t in tracks) {
        sources.add(await _sourceFor(t));
      }
      await _player.setAudioSource(
        ConcatenatingAudioSource(children: sources),
        initialIndex: index,
        initialPosition: Duration.zero,
      );
    } else {
      await _playSingle(tracks[index]);
    }
    await _player.play();
    notifyListeners();
  }

  Future<void> _playSingle(Track t) async {
    await _player.setAudioSource(await _sourceFor(t));
    await _player.play();
  }

  /// Original file when output >= source, otherwise a converted temp file.
  Future<AudioSource> _sourceFor(Track t) async {
    String path = t.filePath;
    if (outputQuality.rank > t.sourceQuality.rank) {
      try {
        final f = await _converter.convert(t, outputQuality);
        path = f.path;
      } catch (e) {
        debugPrint('conversion failed, playing original: $e');
      }
    }
    final art = (t.artPath != null && File(t.artPath!).existsSync())
        ? Uri.file(t.artPath!)
        : null;
    return AudioSource.file(
      path,
      tag: MediaItem(
        id: t.id,
        title: t.title,
        artist: t.artist,
        album: t.album,
        artUri: art,
        duration: t.duration,
      ),
    );
  }

  void _onIndexChanged(int? i) {
    if (i != null && i != _fallbackIndex) {
      _fallbackIndex = i;
      notifyListeners();
    }
  }

  void setOutputQuality(Quality q) {
    outputQuality = q;
    notifyListeners();
    if (current != null) setQueue(queue, _idx); // reload whole chain
  }

  Future<void> toggle() => playing ? _player.pause() : _player.play();
  Future<void> seek(Duration d) => _player.seek(d);

  Future<void> next() async {
    if (crossfadeSeconds > 0) return _crossfadeTo(_idx + 1);
    if (_idx < queue.length - 1) await _player.seekToNext();
  }

  Future<void> previous() async {
    if (crossfadeSeconds > 0) return _crossfadeTo(_idx - 1);
    if (_idx > 0) await _player.seekToPrevious();
  }

  /// Two-player crossfade used when [crossfadeSeconds] > 0.
  Future<void> _crossfadeTo(int i) async {
    if (i < 0 || i >= queue.length) return;
    final dur = Duration(milliseconds: (crossfadeSeconds * 1000).round());
    _fallbackIndex = i;
    notifyListeners();

    await _fadePlayer.setAudioSource(await _sourceFor(queue[i]));
    await _fadePlayer.setVolume(0);
    unawaited(_fadePlayer.play());

    // ramp: main fades out, fade player fades in
    final steps = 20;
    for (var s = 1; s <= steps; s++) {
      await Future<void>.delayed(dur ~/ steps);
      await _fadePlayer.setVolume(s / steps);
      await _player.setVolume(1 - s / steps);
    }
    final old = _player;
    _swapFadePlayer();
    unawaited(old.stop());
    await old.setVolume(1);
    notifyListeners();
  }

  /// After the fade the fade-player is the audible one; re-anchor the main
  /// player on the same (possibly converted) source so position and controls
  /// report the new track, then silence the fade player.
  void _swapFadePlayer() {
    _sourceFor(queue[_fallbackIndex]).then((src) {
      _player
          .setAudioSource(src, initialPosition: _fadePlayer.position)
          .then((_) {
        _fadePlayer.setVolume(0);
        _fadePlayer.pause();
      });
    });
  }

  @override
  void dispose() {
    _player.dispose();
    _fadePlayer.dispose();
    super.dispose();
  }
}
