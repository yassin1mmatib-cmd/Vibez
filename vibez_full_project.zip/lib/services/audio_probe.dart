import 'dart:io';
import '../models/quality.dart';

/// Reads the REAL sample rate / bit depth from the file header,
/// fully offline (no ffprobe needed for WAV/FLAC).
class AudioProbe {
  /// Returns (sampleRate, bitDepth, format).
  static Future<(int, int, String)> probe(String path) async {
    final raf = await File(path).open();
    final head = await raf.read(256);
    await raf.close();

    // --- FLAC: 'fLaC' magic, STREAMINFO at offset 4 ---
    if (head.length >= 20 && head[0] == 0x66 && head[1] == 0x4C &&
        head[2] == 0x61 && head[3] == 0x43) {
      final b = head;
      final sr = (b[12] << 12) | (b[13] << 4) | (b[14] >> 4);
      final bps = ((b[18] & 0x01) << 4) | (b[19] >> 4);
      return (sr, bps, 'FLAC');
    }

    // --- WAV / RIFF ---
    if (head.length >= 12 && head[0] == 0x52 && head[1] == 0x49 &&
        head[2] == 0x46 && head[3] == 0x46 &&
        head[8] == 0x57 && head[9] == 0x41) {
      int p = 12;
      while (p + 8 <= head.length) {
        final id = String.fromCharCodes(head.sublist(p, p + 4));
        final size = head[p + 4] | (head[p + 5] << 8) |
                     (head[p + 6] << 16) | (head[p + 7] << 24);
        if (id == 'fmt ' && p + 24 <= head.length) {
          final d = p + 8;
          final sr = head[d + 4] | (head[d + 5] << 8) |
                     (head[d + 6] << 16) | (head[d + 7] << 24);
          final bps = head[d + 14] | (head[d + 15] << 8);
          return (sr, bps, 'WAV');
        }
        p += 8 + size + (size.isOdd ? 1 : 0);
      }
    }

    // --- MP3 frame sync ---
    if (head.length >= 3 && head[0] == 0xFF && (head[1] & 0xE0) == 0xE0) {
      return (44100, 16, 'MP3');
    }
    return (44100, 16, path.split('.').last.toUpperCase());
  }

  /// Maps raw (sr, bits, format) onto the app's quality ladder.
  static Quality detectQuality(int sr, int bits, String format) {
    if (format == 'MP3' || format == 'OGG' || format == 'OPUS' || format == 'AAC') {
      return Quality.mp3;
    }
    if (bits >= 24 && sr >= 192000) return Quality.hires192;
    if (bits >= 24 && sr >= 96000) return Quality.hires96;
    return Quality.cd;
  }
}
