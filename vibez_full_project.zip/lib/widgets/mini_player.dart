import 'dart:io';
import 'package:flutter/material.dart';
import '../models/track.dart';
import '../services/player_service.dart';
import '../screens/player_screen.dart';

class MiniPlayer extends StatelessWidget {
  final PlayerService player;
  const MiniPlayer({super.key, required this.player});

  @override
  Widget build(BuildContext context) {
    final Track? t = player.current;
    if (t == null) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => PlayerScreen(player: player))),
      child: Container(
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E24),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          _art(t),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.title, maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(t.artist, maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF9A9AA3), fontSize: 13)),
            ]),
          ),
          IconButton(icon: const Icon(Icons.favorite_border), onPressed: () {}),
          IconButton(
            icon: Icon(player.playing ? Icons.pause_circle : Icons.play_circle,
                size: 34),
            onPressed: player.toggle,
          ),
        ]),
      ),
    );
  }

  Widget _art(Track t) {
    final has = t.artPath != null && File(t.artPath!).existsSync();
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 44, height: 44, color: const Color(0xFF2A2A31),
        child: has
            ? Image.file(File(t.artPath!), fit: BoxFit.cover)
            : const Icon(Icons.album, color: Colors.white54),
      ),
    );
  }
}
