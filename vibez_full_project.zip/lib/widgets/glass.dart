import 'dart:ui';
import 'package:flutter/material.dart';

/// Apple-style Liquid Glass surface: blur + specular gradient border.
/// Put it on top of colorful content (album art) for the real effect.
class LiquidGlass extends StatelessWidget {
  final Widget child;
  final double radius;
  final double blur;
  final Color tint;
  final EdgeInsets padding;

  const LiquidGlass({
    super.key,
    required this.child,
    this.radius = 24,
    this.blur = 28,
    this.tint = const Color(0x30FFFFFF),
    this.padding = const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            gradient: LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [tint, const Color(0x12FFFFFF)],
            ),
            border: Border.all(color: Colors.white.withOpacity(0.35)),
          ),
          child: child,
        ),
      ),
    );
  }
}
