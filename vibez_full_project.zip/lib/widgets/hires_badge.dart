import 'package:flutter/material.dart';
import '../models/quality.dart';

/// The small gold Hi-Res badge shown next to album/track titles,
/// exactly like the screenshots. Only rendered when the track is Hi-Res.
class HiResBadge extends StatelessWidget {
  final bool visible;
  const HiResBadge({super.key, this.visible = true});

  @override
  Widget build(BuildContext context) {
    if (!visible) return const SizedBox.shrink();
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 4)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Image.asset('assets/badges/hires_badge.png', width: 34),
      ),
    );
  }
}

/// Compact gold quality chip used inside the player screen
/// (the "MP3" pill in screenshot 1000169667).
class QualityChip extends StatelessWidget {
  final Quality q;
  final VoidCallback? onTap;
  const QualityChip({super.key, required this.q, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF2A2A31),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (q == Quality.mp3)
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: const Color(0xFF6B5518),
                borderRadius: BorderRadius.circular(3),
              ),
              child: const Text('MP3',
                  style: TextStyle(fontSize: 9, fontWeight: FontWeight.bold,
                      color: Color(0xFFE8B44A))),
            ),
          if (q == Quality.mp3) const SizedBox(width: 6),
          Text(q.label.split(' ').first,
              style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}
