import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'screens/discover_screen.dart';
import 'screens/library_screen.dart';
import 'screens/search_screen.dart';
import 'services/library_service.dart';
import 'services/player_service.dart';
import 'theme.dart';
import 'widgets/mini_player.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.vibez.audio',
    androidNotificationChannelName: 'Vibez playback',
    androidNotificationOngoing: true,
    androidShowNotificationBadge: true,
  );
  runApp(const VibezApp());
}

class VibezApp extends StatefulWidget {
  const VibezApp({super.key});
  @override
  State<VibezApp> createState() => _VibezAppState();
}

class _VibezAppState extends State<VibezApp> {
  final player = PlayerService();
  final lib = LibraryService();

  @override
  void initState() {
    super.initState();
    lib.scan();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vibez',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      home: HomeShell(player: player, lib: lib),
    );
  }
}

class HomeShell extends StatefulWidget {
  final PlayerService player;
  final LibraryService lib;
  const HomeShell({super.key, required this.player, required this.lib});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 2; // open on Library like the screenshots

  @override
  Widget build(BuildContext context) {
    final screens = [
      DiscoverScreen(lib: widget.lib, player: widget.player),
      const _Placeholder(icon: Icons.queue_music, label: 'Playlists'),
      LibraryScreen(lib: widget.lib, player: widget.player),
      SearchScreen(lib: widget.lib, player: widget.player),
    ];
    return Scaffold(
      body: Stack(children: [
        screens[tab],
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            MiniPlayer(player: widget.player),
            _navBar(),
          ]),
        ),
      ]),
    );
  }

  Widget _navBar() {
    const items = [
      (Icons.explore, 'Discover'),
      (Icons.menu_book_outlined, 'Playlists'),
      (Icons.library_music, 'Library'),
      (Icons.search, 'Search'),
    ];
    return Container(
      padding: const EdgeInsets.only(top: 6, bottom: 14),
      decoration: const BoxDecoration(
        color: Color(0xF20B0B0E),
        border: Border(top: BorderSide(color: Colors.white10)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (i) {
          final active = i == tab;
          return GestureDetector(
            onTap: () => setState(() => tab = i),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(items[i].$1,
                  size: 26,
                  color: active ? Colors.white : const Color(0xFF8A8A93)),
              const SizedBox(height: 2),
              Text(items[i].$2, style: TextStyle(
                  fontSize: 11,
                  color: active ? Colors.white : const Color(0xFF8A8A93))),
            ]),
          );
        }),
      ),
    );
  }
}

class _Placeholder extends StatelessWidget {
  final IconData icon;
  final String label;
  const _Placeholder({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 48, color: const Color(0xFF5A5A63)),
      const SizedBox(height: 8),
      Text(label, style: const TextStyle(color: Color(0xFF5A5A63))),
    ]),
  );
}
