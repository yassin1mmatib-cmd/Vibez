import 'dart:io';
import 'package:flutter/material.dart';
import 'package:palette_generator/palette_generator.dart';
import '../models/quality.dart';
import '../models/track.dart';
import '../services/player_service.dart';
import '../widgets/glass.dart';
import '../widgets/hires_badge.dart';

class PlayerScreen extends StatefulWidget {
  final PlayerService player;
  const PlayerScreen({super.key, required this.player});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  Color _glow = const Color(0xFF0B0B0E);
  bool _showQualitySheet = false;
  String? _paletteFor;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.player,
      builder: (_, __) {
        final Track? t = widget.player.current;
        if (t == null) return const Scaffold();
        _updatePalette(t);
        final q = widget.player.outputQuality;
        return Scaffold(
          backgroundColor: _glow,
          body: SafeArea(
            child: Stack(children: [
              Column(children: [
                const SizedBox(height: 8),
                _albumArt(t),
                const SizedBox(height: 24),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  QualityChip(q: q, onTap: _toggleSheet),
                  const SizedBox(width: 12),
                  LiquidGlass(
                    radius: 20,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    child: Row(mainAxisSize: MainAxisSize.min, children: const [
                      Icon(Icons.smartphone, size: 16),
                      SizedBox(width: 6),
                      Text('This device'),
                    ]),
                  ),
                ]),
                const Spacer(),
                _title(t),
                _seekBar(),
                _controls(),
                const SizedBox(height: 20),
              ]),
              if (_showQualitySheet)
                _QualitySheet(
                  source: t.sourceQuality,
                  selected: q,
                  onSelect: (nq) {
                    widget.player.setOutputQuality(nq);
                    _toggleSheet();
                  },
                ),
            ]),
          ),
        );
      },
    );
  }

  void _updatePalette(Track t) {
    final art = t.artPath;
    if (art == null || !File(art).existsSync() || _paletteFor == art) return;
    _paletteFor = art;
    PaletteGenerator.fromImageProvider(FileImage(File(art)), size: const Size(120, 120))
        .then((pal) {
      final c = pal.dominantColor?.color ?? const Color(0xFF0B0B0E);
      if (mounted && _paletteFor == art) setState(() => _glow = c.withOpacity(0.35));
    }).catchError((_) {});
  }

  void _toggleSheet() => setState(() => _showQualitySheet = !_showQualitySheet);

  Widget _albumArt(Track t) {
    final hasArt = t.artPath != null && File(t.artPath!).existsSync();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: AspectRatio(
        aspectRatio: 1,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Container(
            color: const Color(0xFF2A2A31),
            width: double.infinity,
            child: Stack(fit: StackFit.expand, children: [
              if (hasArt)
                Image.file(File(t.artPath!), fit: BoxFit.cover)
              else
                const Center(child: Icon(Icons.album,
                    size: 120, color: Colors.white24)),
              if (t.isHiRes)
                const Positioned(right: 12, bottom: 12, child: HiResBadge()),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _title(Track t) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            Text('${t.artist} • ${t.album}',
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Color(0xFF9A9AA3))),
          ]),
        ),
        IconButton(icon: const Icon(Icons.favorite_border), onPressed: () {}),
        const Icon(Icons.more_vert),
      ]),
    );
  }

  Widget _seekBar() {
    final p = widget.player;
    final d = p.duration.inMilliseconds > 0 ? p.duration : const Duration(seconds: 1);
    final pos = p.position;
    final remain = d - pos;
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 18, 28, 6),
      child: Column(children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 3,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5)),
          child: Slider(
            value: pos.inMilliseconds.clamp(0, d.inMilliseconds).toDouble(),
            max: d.inMilliseconds.toDouble(),
            activeColor: Colors.white,
            inactiveColor: Colors.white24,
            onChanged: (v) => p.seek(Duration(milliseconds: v.toInt())),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(_fmt(pos), style: const TextStyle(fontSize: 12)),
            Text('-${_fmt(remain)}', style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ]),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes, s = d.inSeconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Widget _controls() {
    final p = widget.player;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        IconButton(icon: const Icon(Icons.shuffle), onPressed: () {}),
        IconButton(iconSize: 34, icon: const Icon(Icons.skip_previous),
            onPressed: p.previous),
        GestureDetector(
          onTap: p.toggle,
          child: Icon(p.playing ? Icons.pause_circle_filled : Icons.play_circle_filled,
              size: 68),
        ),
        IconButton(iconSize: 34, icon: const Icon(Icons.skip_next),
            onPressed: p.next),
        IconButton(icon: const Icon(Icons.repeat), onPressed: () {}),
      ]),
    );
  }
}

class _QualitySheet extends StatelessWidget {
  final Quality source;
  final Quality selected;
  final ValueChanged<Quality> onSelect;
  const _QualitySheet(
      {required this.source, required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Container(
        color: Colors.black54,
        alignment: Alignment.bottomCenter,
        child: Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E24),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Playback quality',
                style: Theme.of(context).textTheme.titleMedium!
                    .copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('Source file: ${source.label}',
                style: const TextStyle(color: Color(0xFF9A9AA3), fontSize: 12)),
            const SizedBox(height: 16),
            ...Quality.values.map((q) {
              final ok = canConvert(source: source, out: q);
              final sel = q == selected;
              return ListTile(
                enabled: ok,
                leading: q.badge(size: 36),
                title: Text(q.label,
                    style: TextStyle(
                        color: ok ? Colors.white : Colors.white30,
                        fontWeight: sel ? FontWeight.w800 : FontWeight.w400)),
                subtitle: Text(
                    ok
                        ? '${q.bitrateMbps.toStringAsFixed(q.bitrateMbps < 1 ? 0 : 2)} Mbps'
                        : 'Higher than the source file',
                    style: const TextStyle(color: Color(0xFF9A9AA3))),
                trailing: sel
                    ? const Icon(Icons.check, color: Color(0xFFE8B44A))
                    : null,
                onTap: ok ? () => onSelect(q) : null,
              );
            }),
          ]),
        ),
      ),
    );
  }
}
