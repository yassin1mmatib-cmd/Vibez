import 'dart:io';
import 'package:flutter/material.dart';
import '../models/track.dart';
import '../services/library_service.dart';
import '../services/player_service.dart';
import '../widgets/hires_badge.dart';

class LibraryScreen extends StatefulWidget {
  final LibraryService lib;
  final PlayerService player;
  const LibraryScreen({super.key, required this.lib, required this.player});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

Widget artThumb(Track t, {double size = 52}) {
  final has = t.artPath != null && File(t.artPath!).existsSync();
  return ClipRRect(
    borderRadius: BorderRadius.circular(6),
    child: Container(
      width: size, height: size, color: const Color(0xFF2A2A31),
      child: has
          ? Image.file(File(t.artPath!), fit: BoxFit.cover)
          : const Icon(Icons.album, color: Colors.white38),
    ),
  );
}

class _LibraryScreenState extends State<LibraryScreen> {
  bool gridMode = false;

  @override
  Widget build(BuildContext context) {
    final lib = widget.lib;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Library',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
        actions: const [
          Padding(padding: EdgeInsets.all(12), child: Icon(Icons.add, size: 28)),
          Padding(padding: EdgeInsets.all(12), child: Icon(Icons.search, size: 28)),
        ],
      ),
      body: Column(children: [
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: const [
              _FilterChip(label: 'Releases', active: true),
              _FilterChip(label: 'Artists'),
              _FilterChip(label: 'Labels'),
              _FilterChip(label: 'Folders'),
              _FilterChip(label: 'Playlists', icon: Icons.download),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            _viewToggle(),
            const SizedBox(width: 16),
            const Icon(Icons.keyboard_arrow_down),
            const SizedBox(width: 4),
            const Text('Recently added'),
          ]),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: lib.scanning
              ? const Center(child: CircularProgressIndicator())
              : lib.tracks.isEmpty
                  ? Center(
                      child: TextButton.icon(
                        onPressed: lib.scan,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Scan device for music'),
                      ),
                    )
                  : gridMode ? _grid(lib.tracks) : _list(lib.tracks),
        ),
      ]),
    );
  }

  Widget _viewToggle() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF2A2A31),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(children: [
        _vtBtn(Icons.view_list, !gridMode),
        _vtBtn(Icons.grid_view, gridMode),
      ]),
    );
  }

  Widget _vtBtn(IconData icon, bool active) {
    return GestureDetector(
      onTap: () => setState(() => gridMode = icon == Icons.grid_view),
      child: Container(
        width: 44, height: 34,
        decoration: BoxDecoration(
          color: active ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Icon(icon, size: 20,
            color: active ? Colors.black : Colors.white70),
      ),
    );
  }

  Widget _list(List<Track> tracks) {
    return ListView.separated(
      itemCount: tracks.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: Colors.white10),
      itemBuilder: (_, i) {
        final t = tracks[i];
        return ListTile(
          leading: artThumb(t),
          title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${t.format} • ${t.artist}',
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Color(0xFF9A9AA3), fontSize: 13)),
          trailing: HiResBadge(visible: t.isHiRes),
          onTap: () => widget.player.setQueue(tracks, i),
        );
      },
    );
  }

  Widget _grid(List<Track> tracks) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, mainAxisSpacing: 16, crossAxisSpacing: 16,
          childAspectRatio: 0.8),
      itemCount: tracks.length,
      itemBuilder: (_, i) {
        final t = tracks[i];
        return GestureDetector(
          onTap: () => widget.player.setQueue(tracks, i),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: (t.artPath != null && File(t.artPath!).existsSync())
                    ? Image.file(File(t.artPath!), fit: BoxFit.cover)
                    : Container(
                        color: const Color(0xFF2A2A31), width: double.infinity,
                        child: const Icon(Icons.album, color: Colors.white38, size: 48)),

              ),
            ),
            const SizedBox(height: 6),
            Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('${t.format} • ${t.artist}',
                maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Color(0xFF9A9AA3), fontSize: 12)),
          ]),
        );
      },
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final IconData? icon;
  const _FilterChip({required this.label, this.active = false, this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: active ? Colors.white : const Color(0xFF2A2A31),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(children: [
        if (icon != null) ...[
          Icon(icon, size: 16, color: active ? Colors.black : Colors.white),
          const SizedBox(width: 6),
        ],
        Text(label, style: TextStyle(
            color: active ? Colors.black : Colors.white,
            fontWeight: FontWeight.w600)),
      ]),
    );
  }
}
