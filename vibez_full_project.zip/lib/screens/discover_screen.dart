import 'package:flutter/material.dart';
import '../services/library_service.dart';
import '../services/player_service.dart';
import '../theme.dart';
import '../widgets/hires_badge.dart';

/// Local adaptation of the Qobuz "Discover" screen.
/// Since Vibez plays device files, sections highlight the local library:
/// "Top Hi-Res on this device", "Recently added", "Album of the week" (random pick).
class DiscoverScreen extends StatelessWidget {
  final LibraryService lib;
  final PlayerService player;
  const DiscoverScreen({super.key, required this.lib, required this.player});

  @override
  Widget build(BuildContext context) {
    final hiRes = lib.tracks.where((t) => t.isHiRes).toList();
    final recent = lib.tracks.reversed.take(6).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Vibez',
            style: AppTheme.fraktur(34).copyWith(fontWeight: FontWeight.w400)),
        actions: const [
          Padding(padding: EdgeInsets.all(12), child: Icon(Icons.tune)),
          Padding(padding: EdgeInsets.all(12), child: Icon(Icons.notifications_none)),
          Padding(padding: EdgeInsets.all(12), child: Icon(Icons.settings)),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _hero(context, hiRes),
        const SizedBox(height: 28),
        if (recent.isNotEmpty) ...[
          _sectionTitle('Recently added'),
          SizedBox(
            height: 210,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: recent.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => _albumCard(recent[i], hiRes),
            ),
          ),
        ],
        const SizedBox(height: 28),
        _sectionTitle('Your Hi-Res collection'),
        ...hiRes.take(4).map((t) => ListTile(
          contentPadding: EdgeInsets.zero,
          leading: (t.artPath != null && File(t.artPath!).existsSync())
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.file(File(t.artPath!), width: 48, height: 48, fit: BoxFit.cover))
              : Container(
                  width: 48, height: 48, color: const Color(0xFF2A2A31),
                  child: const Icon(Icons.album, color: Colors.white38)),
          title: Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${t.artist} • ${t.format}',
              style: const TextStyle(color: Color(0xFF9A9AA3), fontSize: 13)),
          trailing: const HiResBadge(),
          onTap: () => player.setQueue(hiRes, hiRes.indexOf(t)),
        )),
      ]),
    );
  }

  Widget _hero(BuildContext context, List hiRes) {
    return Container(
      height: 160,
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          colors: [Color(0xFF3A1C1C), Color(0xFF141020)],
          begin: Alignment.topLeft, end: Alignment.bottomRight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Vibez Top 50 in Hi-Res',
            style: Theme.of(context).textTheme.titleLarge!
                .copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text('ON THIS DEVICE', style: TextStyle(
            color: AppTheme.gold, fontWeight: FontWeight.w700,
            letterSpacing: 2, fontSize: 12)),
        const Spacer(),
        Text('${hiRes.length} Hi-Res tracks found',
            style: const TextStyle(color: AppTheme.textDim)),
      ]),
    );
  }

  Widget _sectionTitle(String s) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(s, style: const TextStyle(
        fontSize: 20, fontWeight: FontWeight.w800)),
  );

  Widget _albumCard(dynamic t, List hiRes) {
    return GestureDetector(
      onTap: () => player.setQueue(hiRes, hiRes.indexOf(t)),
      child: SizedBox(
        width: 150,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Stack(children: [
                Container(
                  width: 150, color: const Color(0xFF2A2A31),
                  child: const Icon(Icons.album, color: Colors.white38, size: 40),
                ),
                if (t.isHiRes)
                  const Positioned(right: 8, bottom: 8, child: HiResBadge()),
              ]),
            ),
          ),
          const SizedBox(height: 6),
          Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          Text(t.artist, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: AppTheme.textDim, fontSize: 12)),
        ]),
      ),
    );
  }
}
