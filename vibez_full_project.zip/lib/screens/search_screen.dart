import 'dart:io';
import 'package:flutter/material.dart';
import '../models/track.dart';
import '../services/library_service.dart';
import '../services/player_service.dart';
import '../widgets/hires_badge.dart';

class SearchScreen extends StatefulWidget {
  final LibraryService lib;
  final PlayerService player;
  const SearchScreen({super.key, required this.lib, required this.player});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String query = '';
  final recent = <String>[];

  @override
  Widget build(BuildContext context) {
    final results = query.isEmpty ? <Track>[]
        : widget.lib.tracks.where((t) =>
            t.title.toLowerCase().contains(query.toLowerCase()) ||
            t.artist.toLowerCase().contains(query.toLowerCase()) ||
            t.album.toLowerCase().contains(query.toLowerCase())).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Search',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800))),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'Albums, artists, tracks...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: const Color(0xFF1E1E24),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        Expanded(
          child: query.isEmpty
              ? const Center(child: Text('Recent searches',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)))
              : ListView.builder(
                  itemCount: results.length,
                  itemBuilder: (_, i) {
                    final t = results[i];
                    return ListTile(
                      leading: (t.artPath != null && File(t.artPath!).existsSync())
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: Image.file(File(t.artPath!),
                                  width: 46, height: 46, fit: BoxFit.cover))
                          : Container(
                              width: 46, height: 46,
                              decoration: BoxDecoration(
                                color: const Color(0xFF2A2A31),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Icon(Icons.album, color: Colors.white38),
                            ),
                      title: Text(t.title, maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${t.format} • ${t.artist}',
                          maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Color(0xFF9A9AA3), fontSize: 13)),
                      trailing: HiResBadge(visible: t.isHiRes),
                      onTap: () => widget.player.setQueue(results, i),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
