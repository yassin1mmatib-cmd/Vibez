import 'package:flutter/material.dart';
import '../models/quality.dart';
import '../services/player_service.dart';

/// Settings screen matching screenshot 1000169668 (Wi-Fi / Mobile data
/// sections with gold Hi-Res icons). For a local player these are the
/// *default output qualities* applied when a track loads.
class QualitySettingsScreen extends StatefulWidget {
  final PlayerService player;
  const QualitySettingsScreen({super.key, required this.player});

  @override
  State<QualitySettingsScreen> createState() => _QualitySettingsScreenState();
}

class _QualitySettingsScreenState extends State<QualitySettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Default audio quality',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Choose the quality used when playback starts. '
            'Higher qualities need more processing power.',
            style: TextStyle(color: Color(0xFF9A9AA3))),
        const SizedBox(height: 24),
        _section('Default playback'),
        ...Quality.values.map((q) => _row(q, subtitle: _sub(q))),
      ]),
    );
  }

  String _sub(Quality q) => switch (q) {
        Quality.hires192 => '24-bit up to 192 kHz',
        Quality.hires96 => '24-bit up to 96 kHz',
        Quality.cd => '16-bit / 44.1 kHz',
        Quality.mp3 => '320 kbps',
      };

  Widget _section(String s) => Padding(
    padding: const EdgeInsets.only(bottom: 12, top: 8),
    child: Text(s, style: const TextStyle(
        fontSize: 20, fontWeight: FontWeight.w800)),
  );

  Widget _row(Quality q, {required String subtitle}) {
    final sel = widget.player.outputQuality == q;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: q.badge(size: 44),
      title: Text(q.label.split(' ').first,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
      subtitle: Text(subtitle,
          style: const TextStyle(color: Color(0xFF9A9AA3))),
      trailing: sel ? const Icon(Icons.check, color: Color(0xFFE8B44A)) : null,
      onTap: () {
        widget.player.setOutputQuality(q);
        setState(() {});
      },
    );
  }
}
